
document.addEventListener("DOMContentLoaded", function(){

const fechaInput = document.getElementById("fecha");
const horaSelect = document.getElementById("hora");


fechaInput.addEventListener("change", function(){

const fecha = this.value;

horaSelect.innerHTML = "<option>Cargando...</option>";

fetch("obtener_horas.php?fecha=" + fecha)
.then(res => res.json())
.then(data => {

horaSelect.innerHTML = "";

if(data.length === 0){

horaSelect.innerHTML = "<option>No hay horas disponibles</option>";
return;

}

data.forEach(h => {

let option = document.createElement("option");

option.value = h;
option.textContent = h;

horaSelect.appendChild(option);

});

});

});

});