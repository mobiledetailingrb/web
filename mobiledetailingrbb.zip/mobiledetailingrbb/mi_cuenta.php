<?php
session_start();
require_once __DIR__ . "/config/conexion.php";

if (!isset($_SESSION['IdUsuario'])) {
    header("Location: login.php");
    exit();
}

$idUsuario = $_SESSION['IdUsuario'];

/* Usuario */
$stmt = $conexion->prepare("
    SELECT Nombre, Apellido, Correo, Telefono
    FROM usuarios
    WHERE IdUsuario = ?
");
$stmt->bind_param("i", $idUsuario);
$stmt->execute();
$usuario = $stmt->get_result()->fetch_assoc();

/* Resumen */
$stmt2 = $conexion->prepare("
    SELECT 
        COUNT(*) AS total,
        SUM(Estado = 'Completada') AS completadas
    FROM citas
    WHERE IdCliente = ?
");
$stmt2->bind_param("i", $idUsuario);
$stmt2->execute();
$resumen = $stmt2->get_result()->fetch_assoc();

/* Próxima cita */
$stmt3 = $conexion->prepare("
    SELECT Fecha, HoraInicio, HoraFin
    FROM citas
    WHERE IdCliente = ?
    AND Fecha >= CURDATE()
    ORDER BY Fecha ASC
    LIMIT 1
");
$stmt3->bind_param("i", $idUsuario);
$stmt3->execute();
$proxima = $stmt3->get_result()->fetch_assoc();

/* Citas */
$stmt4 = $conexion->prepare("
    SELECT 
        c.IdCita,
        c.Fecha,
        c.HoraInicio,
        c.HoraFin,
        c.TipoAuto,
        c.MarcaAuto,
        c.ModeloAuto,
        c.DireccionTexto,
        c.Latitud,
        c.Longitud,
        c.Estado,
        s.NombreServicio
    FROM citas c
    LEFT JOIN servicios s 
        ON c.IdServicio = s.IdServicio
    WHERE c.IdCliente = ?
    ORDER BY c.Fecha DESC
");
$stmt4->bind_param("i", $idUsuario);
$stmt4->execute();
$citas = $stmt4->get_result();
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Cuenta</title>

    <link rel="stylesheet" href="css/header.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/cuenta.css">
    <link rel="stylesheet" href="css/footer.css">
</head>

<body>

<?php include("includes/header.php"); ?>

<section class="cuenta-section">
    <div class="cuenta-container">

        <div class="perfil-card">
            <h3>Perfil</h3>
                <p><strong>Nombre:</strong> <?= $usuario['Nombre'] . " " . $usuario['Apellido']; ?></p>
                <p><strong>Email:</strong> <?= $usuario['Correo']; ?></p>
                <p><strong>Teléfono:</strong> <?= $usuario['Telefono']; ?></p>
            <a href="editar_perfil.php" class="btn-editar">Editar perfil</a>
        </div>

        <div class="resumen-card">
            <h3>Resumen</h3>

            <div class="stats">
                <div class="stat">
                    <span>Total de citas</span>
                    <strong><?= $resumen['total']; ?></strong>
                </div>

                <div class="stat">
                    <span>Citas completadas</span>
                    <strong><?= $resumen['completadas']; ?></strong>
                </div>

                <div class="stat">
                    <span>Próxima cita</span>
                    <strong>
                        <?php
                        if ($proxima) {
                            echo $proxima['Fecha'] . " " . $proxima['HoraInicio'] . " - " . $proxima['HoraFin'];
                        } else {
                            echo "Sin citas";
                        }
                        ?>
                    </strong>
                </div>
            </div>
        </div>

        <!-- CITAS -->
        <div class="citas-card">
            <h3>Mis citas</h3>

            <div class="tabla-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Servicio</th>
                            <th>Fecha</th>
                            <th>Hora</th>
                            <th>Auto</th>
                            <th>Dirección</th>
                            <th>Estado</th>
                            <th>Acción</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php while ($cita = $citas->fetch_assoc()) { ?>
                        <tr>
                            <td><?= $cita['NombreServicio']; ?></td>

                            <td><?= $cita['Fecha']; ?></td>

                            <td>
                                <?= $cita['HoraInicio'] . " - " . $cita['HoraFin']; ?>
                            </td>

                            <td>
                                <?= $cita['TipoAuto']; ?><br>
                                <?= $cita['MarcaAuto'] . " " . $cita['ModeloAuto']; ?>
                            </td>

                            <td>
                                <?= $cita['DireccionTexto']; ?><br>

                                <a target="_blank"
                                   href="https://www.google.com/maps?q=<?= $cita['Latitud']; ?>,<?= $cita['Longitud']; ?>">
                                   Ver mapa
                                </a>
                            </td>

                            <td>
                                <span class="estado <?= strtolower($cita['Estado']); ?>">
                                    <?= $cita['Estado']; ?>
                                </span>
                            </td>

                            <td>
                                <?php if ($cita['Estado'] == "Pendiente") { ?>
                                    <a href="cancelar_cita.php?id=<?= $cita['IdCita']; ?>" class="btn-cancelar">
                                        Cancelar
                                    </a>
                                <?php } ?>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>

                </table>
            </div>

        </div>

    </div>
</section>

<?php include("includes/footer.php"); ?>
<script>
const hamburger = document.getElementById("hamburger");
const navMenu = document.getElementById("navMenu");

hamburger.addEventListener("click", () => {
    navMenu.classList.toggle("active");
    hamburger.classList.toggle("active");
});
</script>
</body>
</html>