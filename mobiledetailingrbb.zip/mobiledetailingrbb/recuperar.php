<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require_once __DIR__ . "/config/conexion.php";

/* PHPMailer */
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/PHPMailer/src/Exception.php';
require __DIR__ . '/PHPMailer/src/PHPMailer.php';
require __DIR__ . '/PHPMailer/src/SMTP.php';

if (isset($_POST['enviar'])) {

    $correo = $_POST['correo'];

    $sql = $conexion->prepare("SELECT IdUsuario FROM usuarios WHERE Correo = ?");
    $sql->bind_param("s", $correo);
    $sql->execute();
    $result = $sql->get_result();

    if ($result->num_rows > 0) {

        $codigo = rand(100000, 999999);

        $_SESSION['codigo'] = $codigo;
        $_SESSION['correo_recuperacion'] = $correo;
        $_SESSION['expira'] = time() + 300;

        $mail = new PHPMailer(true);

        try {

            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'mobiledetailingrb@gmail.com';
            $mail->Password = 'fxerwtrivxmnkybc';
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;

            $mail->setFrom('mobiledetailingrb@gmail.com', 'Mobile Detailing RB');
            $mail->addAddress($correo);
            $mail->CharSet = 'UTF-8';
            $mail->Encoding = 'base64';
            $mail->isHTML(true);
            $mail->Subject = 'Recuperación de contraseña';
            $mail->Body = "
                <h2>Recuperación de contraseña</h2>
                <p>Tu código es:</p>
                <h1>$codigo</h1>
                <p>Expira en 5 minutos.</p>
            ";

            $mail->send();

            header("Location: verificar_codigo.php");
            exit();

        } catch (Exception $e) {
            $error = "Error al enviar correo";
        }

    } else {
        $error = "El correo no existe";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperar contraseña | Mobile Detailing RBB</title>

    <link rel="stylesheet" href="css/header.css">
    <link rel="stylesheet" href="css/estilos.css">
    <link rel="stylesheet" href="css/footer.css">
</head>

<body>

<?php include("includes/header.php"); ?>

<div class="contenedor-form">
    <div class="card-form">

        <h2>Recuperar contraseña</h2>

        <?php if (isset($error)) { ?>
            <p class="error"><?php echo $error; ?></p>
        <?php } ?>

        <form method="POST">

            <div class="form-group">
                <label>Correo</label>
                <input type="email" name="correo" required>
            </div>

            <button type="submit" name="enviar" class="btn-principal">
                Enviar código
            </button>

        </form>

        <p class="texto-secundario">
            ¿Ya recordaste tu contraseña?
            <a href="login.php">Inicia sesión</a>
        </p>

    </div>
</div>

<?php include("includes/footer.php"); ?>
<script>
const hamburger = document.getElementById("hamburger");
const navMenu = document.getElementById("navMenu");

hamburger.addEventListener("click", () => {
    navMenu.classList.toggle("active");
    hamburger.classList.toggle("active");
});
</script>
</body>
</html>