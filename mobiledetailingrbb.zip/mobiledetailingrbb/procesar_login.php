<?php
session_start();
require_once __DIR__ . "/config/conexion.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $correo   = trim($_POST['correo']);
    $password = $_POST['password'];

    $sql = "SELECT IdUsuario, Nombre, PasswordHash, Rol, Activo 
            FROM usuarios 
            WHERE Correo = ?";

    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("s", $correo);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows === 1) {

        $usuario = $resultado->fetch_assoc();

        if ($usuario['Activo'] == 0) {
            echo "Cuenta desactivada.";
            exit;
        }

        if (password_verify($password, $usuario['PasswordHash'])) {

            $_SESSION['IdUsuario'] = $usuario['IdUsuario'];
            $_SESSION['Nombre']    = $usuario['Nombre'];
            $_SESSION['Rol']       = $usuario['Rol'];

            // 🔥 Redirección inteligente
            if(isset($_SESSION['redirect_after_login'])){

                $redirect = $_SESSION['redirect_after_login'];
                unset($_SESSION['redirect_after_login']);

                header("Location: $redirect");
                exit;

            }else{

                header("Location: index.php");
                exit;

            }

        } else {
            echo "Contraseña incorrecta.";
        }

    } else {
        echo "Usuario no encontrado.";
    }

    $stmt->close();
    $conexion->close();
}
?>