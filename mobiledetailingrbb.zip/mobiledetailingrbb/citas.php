<?php
session_start();
require_once __DIR__ . "/config/conexion.php";

if(!isset($_SESSION['Rol']) || $_SESSION['Rol'] !== 'Admin'){
header("Location: index.php");
exit();
}

$filtro = $_GET['filtro'] ?? 'todas';

$where = "";

if($filtro == "hoy"){
$where = "WHERE c.Fecha = CURDATE()";
}

if($filtro == "manana"){
$where = "WHERE c.Fecha = DATE_ADD(CURDATE(), INTERVAL 1 DAY)";
}

if($filtro == "semana"){
$where = "WHERE c.Fecha BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)";
}

$query = "
SELECT 
c.IdCita,
c.Fecha,
c.HoraInicio,
c.HoraFin,
c.TipoAuto,
c.MarcaAuto,
c.ModeloAuto,
c.DireccionTexto,
c.Latitud,
c.Longitud,
c.Estado,
u.Nombre,
s.NombreServicio

FROM citas c

LEFT JOIN usuarios u 
ON c.IdCliente = u.IdUsuario

LEFT JOIN servicios s 
ON c.IdServicio = s.IdServicio

$where

ORDER BY c.Fecha ASC, c.HoraInicio ASC
";

$citas = $conexion->query($query);
?>

<!DOCTYPE html>
<html lang="es">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Administrar Citas</title>

<link rel="stylesheet" href="css/header.css">
<link rel="stylesheet" href="css/styles.css">
<link rel="stylesheet" href="css/footer.css">
<link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css"/>
<script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
<link rel="stylesheet" href="css/citas-admin.css">
</head>

<body>

<?php include(__DIR__ . "/includes/header.php"); ?>

<section class="admin-container">

<h1 class="admin-title">Administración de Citas</h1>

<div class="filtros">
<a href="citas.php?filtro=hoy">Hoy</a>
<a href="citas.php?filtro=manana">Mañana</a>
<a href="citas.php?filtro=semana">Esta semana</a>
<a href="citas.php?filtro=todas">Todas</a>
</div>

<div id="mapaCitas"></div>

<div class="tabla-wrapper">

<table class="tabla-admin">

<thead>
<tr>
<th>Cliente</th>
<th>Servicio</th>
<th>Fecha</th>
<th>Hora</th>
<th>Auto</th>
<th>Dirección</th>
<th>Estado</th>
<th>Acciones</th>
</tr>
</thead>

<tbody>

<?php 
$marcadores = [];

while($cita = $citas->fetch_assoc()){ 

$marcadores[] = [
"lat"=>$cita['Latitud'],
"lng"=>$cita['Longitud'],
"cliente"=>$cita['Nombre']
];
?>

<tr>

<td><?= $cita['Nombre']; ?></td>

<td><?= $cita['NombreServicio']; ?></td>

<td><?= $cita['Fecha']; ?></td>

<td><?= $cita['HoraInicio']; ?> - <?= $cita['HoraFin']; ?></td>

<td>
<?= $cita['TipoAuto']; ?><br>
<?= $cita['MarcaAuto']; ?> <?= $cita['ModeloAuto']; ?>
</td>

<td>
<?= $cita['DireccionTexto']; ?>
<br>
<a target="_blank"
href="https://www.google.com/maps?q=<?= $cita['Latitud']; ?>,<?= $cita['Longitud']; ?>">
Ver mapa
</a>
</td>

<td class="estado <?= strtolower($cita['Estado']); ?>">
<?= $cita['Estado']; ?>
</td>

<td class="acciones">

<a class="btn confirmar"
   href="actualizar_estado.php?id=<?= $cita['IdCita']; ?>&estado=Confirmada">
   Confirmar
</a>

<a class="btn completar"
   href="actualizar_estado.php?id=<?= $cita['IdCita']; ?>&estado=Completada">
   Completar
</a>

<a class="btn cancelar"
   href="actualizar_estado.php?id=<?= $cita['IdCita']; ?>&estado=Cancelada">
   Cancelar
</a>

<!-- 🔥 NUEVO BOTÓN -->
<a class="btn avisar"
   href="avisar_cliente.php?id=<?= $cita['IdCita']; ?>">
   Avisar
</a>

</td>

</tr>

<?php } ?>

</tbody>
</table>

</div>

</section>

<script>

const citas = <?php echo json_encode($marcadores); ?>;

let map = L.map('mapaCitas').setView([25.987, -98.098], 12);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap'
}).addTo(map);

citas.forEach(cita => {

    if(cita.lat && cita.lng){

        let marker = L.marker([
            parseFloat(cita.lat), 
            parseFloat(cita.lng)
        ]).addTo(map);

        marker.bindPopup(`<b>${cita.cliente}</b>`);

    }

});

</script>

<script>
const hamburger = document.getElementById("hamburger");
const navMenu = document.getElementById("navMenu");

hamburger.addEventListener("click", () => {
navMenu.classList.toggle("active");
hamburger.classList.toggle("active");
});
</script>

<?php include(__DIR__ . "/includes/footer.php"); ?>

</body>
</html>