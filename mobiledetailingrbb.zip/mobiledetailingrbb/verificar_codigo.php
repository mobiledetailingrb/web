<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

/* Validar que exista sesión */
if (!isset($_SESSION['codigo']) || !isset($_SESSION['expira'])) {
    header("Location: recuperar.php");
    exit();
}

/* Procesar formulario */
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $codigo_usuario = trim($_POST['codigo']);
    $codigo_sesion = strval($_SESSION['codigo']);

    if (time() > $_SESSION['expira']) {

        session_destroy();
        $error = "El código expiró";

    } elseif ($codigo_usuario === $codigo_sesion) {

        header("Location: nueva_password.php");
        exit();

    } else {

        $error = "Código incorrecto";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verificar código | Mobile Detailing RBB</title>

    <link rel="stylesheet" href="css/header.css">
    <link rel="stylesheet" href="css/estilos.css">
    <link rel="stylesheet" href="css/footer.css">

    <style>
        .contenedor-form {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .card-form {
            width: 100%;
            max-width: 400px;
        }

        @media (max-width: 480px) {
            .card-form {
                padding: 20px;
            }
        }
    </style>
</head>

<body>

<?php include("includes/header.php"); ?>

<div class="contenedor-form">
    <div class="card-form">

        <h2>Verificar código</h2>

        <?php if (isset($error)) { ?>
            <p class="error"><?php echo $error; ?></p>
        <?php } ?>

        <form method="POST">

            <div class="form-group">
                <label for="codigo">Ingresa el código</label>
                <input 
                    type="text" 
                    name="codigo" 
                    id="codigo" 
                    placeholder="Ej. 123456"
                    required
                >
            </div>

            <button 
                type="submit" 
                class="btn-principal"
            >
                Verificar
            </button>

        </form>

        <p class="texto-secundario">
            ¿No recibiste el código?
            <a href="recuperar.php">Reenviar</a>
        </p>

    </div>
</div>

<?php include("includes/footer.php"); ?>
<script>
const hamburger = document.getElementById("hamburger");
const navMenu = document.getElementById("navMenu");

hamburger.addEventListener("click", () => {
    navMenu.classList.toggle("active");
    hamburger.classList.toggle("active");
});
</script>
</body>
</html>