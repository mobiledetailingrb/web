<?php
session_start();
require_once __DIR__ . "/config/conexion.php";
require_once __DIR__ . "/includes/header.php";
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro | Mobile Detailing RBB</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="css/header.css">
        <link rel="stylesheet" href="css/estilos.css">
    <link rel="stylesheet" href="css/footer.css">
</head>
<body>

<div class="contenedor-form">

    <div class="card-form">
        <h2>Crear Cuenta</h2>

        <form action="procesar_registro.php" method="POST">

            <div class="form-group">
                <label>Nombre</label>
                <input type="text" name="nombre" required>
            </div>

            <div class="form-group">
                <label>Apellido</label>
                <input type="text" name="apellido" required>
            </div>

            <div class="form-group">
                <label>Correo</label>
                <input type="email" name="correo" required>
            </div>

            <div class="form-group">
                <label>Teléfono</label>
                <input type="text" name="telefono" required>
            </div>

            <div class="form-group">
                <label>Contraseña</label>
                <input type="password" name="password" required>
            </div>

            <button type="submit" class="btn-principal">
                Registrarse
            </button>

        </form>

        <p class="texto-secundario">
            ¿Ya tienes cuenta?
            <a href="login.php">Inicia sesión</a>
        </p>
    </div>

</div>
<script>
const hamburger = document.getElementById("hamburger");
const navMenu = document.getElementById("navMenu");

hamburger.addEventListener("click", () => {
    navMenu.classList.toggle("active");
    hamburger.classList.toggle("active");
});
</script>

</body>
</html>