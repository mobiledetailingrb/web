<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require_once __DIR__ . "/config/conexion.php";

/* Validar acceso */
if (!isset($_SESSION['correo_recuperacion'])) {
    header("Location: recuperar.php");
    exit();
}

/* Procesar formulario */
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $nueva = $_POST['nueva'];
    $confirmar = $_POST['confirmar'];

    if ($nueva !== $confirmar) {

        $error = "Las contraseñas no coinciden";

    } else {

        $hash = password_hash($nueva, PASSWORD_DEFAULT);
        $correo = $_SESSION['correo_recuperacion'];

        $sql = $conexion->prepare("UPDATE usuarios SET PasswordHash = ? WHERE Correo = ?");
        $sql->bind_param("ss", $hash, $correo);

        if ($sql->execute()) {

            session_destroy();
            header("Location: login.php");
            exit();

        } else {

            $error = "Error al actualizar la contraseña";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nueva contraseña | Mobile Detailing RBB</title>

    <link rel="stylesheet" href="css/header.css">
    <link rel="stylesheet" href="css/estilos.css">
    <link rel="stylesheet" href="css/footer.css">

    <style>
        .contenedor-form {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .card-form {
            width: 100%;
            max-width: 400px;
        }

        @media (max-width: 480px) {
            .card-form {
                padding: 20px;
            }
        }
    </style>
</head>

<body>

<?php include("includes/header.php"); ?>

<div class="contenedor-form">
    <div class="card-form">

        <h2>Nueva contraseña</h2>

        <?php if (isset($error)) { ?>
            <p class="error"><?php echo $error; ?></p>
        <?php } ?>

        <form method="POST">

            <div class="form-group">
                <label for="nueva">Nueva contraseña</label>
                <input 
                    type="password" 
                    name="nueva" 
                    id="nueva"
                    placeholder="Ingresa tu nueva contraseña"
                    required
                >
            </div>

            <div class="form-group">
                <label for="confirmar">Confirmar contraseña</label>
                <input 
                    type="password" 
                    name="confirmar" 
                    id="confirmar"
                    placeholder="Confirma tu contraseña"
                    required
                >
            </div>

            <button 
                type="submit" 
                name="cambiar" 
                class="btn-principal"
            >
                Cambiar contraseña
            </button>

        </form>

    </div>
</div>

<?php include("includes/footer.php"); ?>
<script>
const hamburger = document.getElementById("hamburger");
const navMenu = document.getElementById("navMenu");

hamburger.addEventListener("click", () => {
    navMenu.classList.toggle("active");
    hamburger.classList.toggle("active");
});
</script>
</body>
</html>