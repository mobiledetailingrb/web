<?php
session_start();
require_once __DIR__ . "/config/conexion.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $nombre   = trim($_POST['nombre']);
    $apellido = trim($_POST['apellido']);
    $correo   = trim($_POST['correo']);
    $telefono = trim($_POST['telefono']);
    $password = $_POST['password'];

    // Verificar si el correo ya existe
    $sql_verificar = "SELECT IdUsuario FROM usuarios WHERE Correo = ?";
    $stmt = $conexion->prepare($sql_verificar);
    $stmt->bind_param("s", $correo);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        echo "El correo ya está registrado.";
        exit;
    }

    // Encriptar contraseña
    $passwordHash = password_hash($password, PASSWORD_DEFAULT);

    // Insertar usuario
    $sql = "INSERT INTO usuarios 
            (Nombre, Apellido, Correo, Telefono, PasswordHash, Rol, Activo, FechaRegistro)
            VALUES (?, ?, ?, ?, ?, 'cliente', 1, NOW())";

    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("sssss", $nombre, $apellido, $correo, $telefono, $passwordHash);
    $stmt->execute();

    header("Location: index.php");
    exit;
}