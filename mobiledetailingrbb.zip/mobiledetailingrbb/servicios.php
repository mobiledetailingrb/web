<?php
session_start();
require_once __DIR__ . "/config/conexion.php";

$servicios = $conexion->query("
SELECT IdServicio, NombreServicio, Descripcion, Precio
FROM servicios
WHERE Activo = 1
");
?>

<!DOCTYPE html>
<html lang="es">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Servicios | Mobile Detailing RB</title>

<link rel="stylesheet" href="css/header.css">
<link rel="stylesheet" href="css/styles.css">
<link rel="stylesheet" href="css/servicios.css">
<link rel="stylesheet" href="css/footer.css">

</head>

<body>

<?php include("includes/header.php"); ?>

<!-- HERO -->
<section class="hero hero-servicios">
<div class="overlay"></div>

<div class="hero-content">
<h1>NUESTROS SERVICIOS</h1>
<p>Detallado profesional a domicilio en Río Bravo</p>
</div>

</section>


<section class="servicios-section">

<div class="servicios-container">


<!-- 1 -->
<div class="servicio-card">

<img src="img/servicios/lavado_exterior.jpg">

<h3>Lavado exterior básico</h3>

<p>
Lavado exterior completo con shampoo automotriz,
limpieza de rines y secado con microfibra para
proteger la pintura del vehículo.
</p>

<div class="precio">$150</div>

<a href="agendar.php" class="btn-reservar">Reservar</a>

</div>


<!-- 2 -->
<div class="servicio-card">

<img src="img/servicios/lavado_interior.jpg">

<h3>Lavado interior básico</h3>

<p>
Aspirado interior, limpieza de tablero, puertas
y superficies para mantener el interior del
vehículo limpio y fresco.
</p>

<div class="precio">$150</div>

<a href="agendar.php" class="btn-reservar">Reservar</a>

</div>


<!-- 3 -->
<div class="servicio-card">

<img src="img/servicios/lavado_completo.jpg">

<h3>Lavado completo</h3>

<p>
Lavado interior y exterior completo con aspirado,
limpieza de tablero, cristales y carrocería.
</p>

<div class="precio">$250</div>

<a href="agendar.php" class="btn-reservar">Reservar</a>

</div>


<!-- 4 -->
<div class="servicio-card">

<img src="img/servicios/pulido.jpg">

<h3>Pulido de pintura</h3>

<p>
Proceso de pulido profesional que elimina rayones
leves, revive el brillo de la pintura y mejora
la apariencia del vehículo.
</p>

<div class="precio">$800</div>

<a href="agendar.php" class="btn-reservar">Reservar</a>

</div>


<!-- 5 -->
<div class="servicio-card">

<img src="img/servicios/detallado_premium.jpg">

<h3>Detallado completo premium</h3>

<p>
Servicio de detallado interior y exterior completo
con limpieza profunda, protección de superficies
y acabado profesional.
</p>

<div class="precio">$1200</div>

<a href="agendar.php" class="btn-reservar">Reservar</a>

</div>


<!-- 6 -->
<div class="servicio-card">

<img src="img/servicios/faros.jpg">

<h3>Restauración de faros</h3>

<p>
Pulido y restauración de faros opacos para mejorar
la visibilidad nocturna y la estética del vehículo.
</p>

<div class="precio">$300</div>

<a href="agendar.php" class="btn-reservar">Reservar</a>

</div>


<!-- 7 -->
<div class="servicio-card">

<img src="img/servicios/motor.jpg">

<h3>Lavado de motor</h3>

<p>
Limpieza profesional del motor eliminando grasa
y suciedad acumulada, cuidando componentes
eléctricos.
</p>

<div class="precio">$350</div>

<a href="agendar.php" class="btn-reservar">Reservar</a>

</div>


<!-- 8 -->
<div class="servicio-card">

<img src="img/servicios/ceramico.jpg">

<h3>Protección cerámica</h3>

<p>
Aplicación de recubrimiento cerámico que protege
la pintura del vehículo contra contaminantes,
rayones leves y rayos UV.
</p>

<div class="precio">$2500</div>

<a href="agendar.php" class="btn-reservar">Reservar</a>

</div>


</div>

</section>
<script>
const hamburger = document.getElementById("hamburger");
const navMenu = document.getElementById("navMenu");

hamburger.addEventListener("click", () => {
    navMenu.classList.toggle("active");
    hamburger.classList.toggle("active");
});
</script>
<?php include("includes/footer.php"); ?>

</body>
</html>