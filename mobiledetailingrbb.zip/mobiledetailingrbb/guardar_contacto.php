<?php

include("config/conexion.php");

$nombre = $_POST['nombre'];
$correo = $_POST['correo'];
$asunto = $_POST['asunto'];
$mensaje = $_POST['mensaje'];

$sql = "INSERT INTO contactos(nombre,correo,asunto,mensaje)
VALUES('$nombre','$correo','$asunto','$mensaje')";

mysqli_query($conexion,$sql);

header("Location: contacto.php?enviado=1");

?>