<?php
session_start();
require_once "config/conexion.php";

$servicios = $conexion->query("SELECT * FROM servicios WHERE Activo=1");
?>

<!DOCTYPE html>
<html lang="es">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Agendar Cita</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<link rel="stylesheet" href="css/header.css">
<link rel="stylesheet" href="css/styles.css">
<link rel="stylesheet" href="css/estilocitas.css">
<link rel="stylesheet" href="css/footer.css">

<link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css"/>
<script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
<script src="js/agenda.js"></script>
</head>

<body>

<?php include "includes/header.php"; ?>

<section class="hero-citas">

<div class="form-container">

<h2>Agenda tu servicio</h2>

<form action="guardar_cita.php" method="POST">

<label>Servicio</label>
<select name="servicio" required>
<?php while($s = $servicios->fetch_assoc()){ ?>
<option value="<?= $s['IdServicio'] ?>">
<?= $s['NombreServicio'] ?> - $<?= $s['Precio'] ?>
</option>
<?php } ?>
</select>

<label>Fecha</label>
<input type="date" name="fecha" id="fecha" required>

<label>Hora</label>
<select name="hora" id="hora" required>
<option value="">Selecciona fecha primero</option>
</select>

<label>Tipo de Auto</label>
<select name="tipo_auto" required>
<option value="">Selecciona</option>
<option>Sedan</option>
<option>SUV</option>
<option>Pickup</option>
<option>Coupe</option>
<option>Hatchback</option>
</select>

<label>Marca</label>
<input type="text" name="marca_auto" required>

<label>Modelo</label>
<input type="text" name="modelo_auto" required>

<label>Dirección</label>

<div class="direccion-box">
<input type="text" id="direccion" placeholder="Ej: Calle 20 #123, Reynosa" autocomplete="off" required>
<ul id="sugerencias"></ul>
</div>
<button type="button" id="btnUbicacion" class="btn-ubicacion">
<i class="fa-solid fa-location-dot"></i> Usar mi ubicación
</button>
<input type="hidden" name="direccion" id="direccionHidden">
<input type="hidden" name="latitud" id="latitud">
<input type="hidden" name="longitud" id="longitud">

<div id="map"></div>

<button type="submit">Agendar cita</button>

</form>

</div>
</section>

<?php include "includes/footer.php"; ?>

<script>

/* ================= MAPA ================= */

let map = L.map('map').setView([25.9873, -98.0986], 13);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);

let marker;

/* ================= ELEMENTOS ================= */

const input = document.getElementById("direccion");
const lista = document.getElementById("sugerencias");

const latInput = document.getElementById("latitud");
const lngInput = document.getElementById("longitud");
const direccionHidden = document.getElementById("direccionHidden");

let seleccionIndex = -1;
let resultados = [];
let debounceTimer;


/* ================= AUTOCOMPLETE ================= */

input.addEventListener("input", () => {

clearTimeout(debounceTimer);

debounceTimer = setTimeout(async () => {

let query = input.value.trim();

if(query.length < 3){
lista.innerHTML = "";
return;
}

lista.innerHTML = "<li>Buscando...</li>";

try{

let url = `https://photon.komoot.io/api/?q=${encodeURIComponent(query)}&limit=5`;
let res = await fetch(url);
let data = await res.json();

lista.innerHTML = "";
resultados = data.features || [];
seleccionIndex = -1;

if(resultados.length === 0){
lista.innerHTML = "<li>No hay resultados</li>";
return;
}

resultados.forEach((lugar, i) => {

let direccion = `
${lugar.properties.name || ""}
${lugar.properties.street || ""}
${lugar.properties.housenumber || ""}
${lugar.properties.city || ""}
`.trim();

let li = document.createElement("li");
li.textContent = direccion;

li.addEventListener("click", () => seleccionar(i));

lista.appendChild(li);

});

}catch(err){
console.error(err);
}

}, 300);

});


/* ================= TECLADO ================= */

input.addEventListener("keydown", (e) => {

let items = lista.querySelectorAll("li");

if(e.key === "ArrowDown"){
e.preventDefault();
seleccionIndex++;
if(seleccionIndex >= items.length) seleccionIndex = 0;
actualizarSeleccion(items);
}

if(e.key === "ArrowUp"){
e.preventDefault();
seleccionIndex--;
if(seleccionIndex < 0) seleccionIndex = items.length - 1;
actualizarSeleccion(items);
}

if(e.key === "Enter"){
e.preventDefault();
if(seleccionIndex >= 0){
seleccionar(seleccionIndex);
}
}

});

function actualizarSeleccion(items){
items.forEach(li => li.classList.remove("active"));
if(items[seleccionIndex]){
items[seleccionIndex].classList.add("active");
}
}


/* ================= SELECCIONAR ================= */

function seleccionar(i){

let lugar = resultados[i];

let direccion = `
${lugar.properties.name || ""}
${lugar.properties.street || ""}
${lugar.properties.housenumber || ""}
${lugar.properties.city || ""}
`.trim();

let lat = lugar.geometry.coordinates[1];
let lon = lugar.geometry.coordinates[0];

setUbicacion(direccion, lat, lon);

}


/* ================= PRECISIÓN (CASA EXACTA) ================= */

input.addEventListener("blur", async () => {

let query = input.value.trim();

if(query.length < 5) return;

try{

let url = `https://corsproxy.io/?https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=1`;

let res = await fetch(url);
let data = await res.json();

if(data.length > 0){
let lugar = data[0];
setUbicacion(lugar.display_name, lugar.lat, lugar.lon);
}

}catch(err){
console.error(err);
}

});


/* ================= MAP CLICK ================= */

map.on("click", async (e) => {

let lat = e.latlng.lat;
let lon = e.latlng.lng;

try{

let url = `https://corsproxy.io/?https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}`;
let res = await fetch(url);
let data = await res.json();

if(data.display_name){
setUbicacion(data.display_name, lat, lon);
}

}catch(err){
console.error(err);
}

});


/* ================= FUNCIÓN CENTRAL ================= */

function setUbicacion(direccion, lat, lon){

input.value = direccion;
direccionHidden.value = direccion;

latInput.value = lat;
lngInput.value = lon;

map.setView([lat, lon], 17);

if(marker) map.removeLayer(marker);

marker = L.marker([lat, lon])
.addTo(map)
.bindPopup(direccion)
.openPopup();

lista.innerHTML = "";

}


/* ================= VALIDACIÓN ================= */

document.querySelector("form").addEventListener("submit", function(e){

if(!latInput.value || !lngInput.value){
e.preventDefault();
alert("Selecciona una ubicación válida");
}

});
const btnUbicacion = document.getElementById("btnUbicacion");

btnUbicacion.addEventListener("click", () => {

if(!navigator.geolocation){
alert("Tu navegador no soporta geolocalización");
return;
}

btnUbicacion.textContent = "Obteniendo ubicación...";

navigator.geolocation.getCurrentPosition(async (pos) => {

let lat = pos.coords.latitude;
let lon = pos.coords.longitude;

try{

let url = `https://corsproxy.io/?https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}`;

let res = await fetch(url);
let data = await res.json();

let direccion = data.display_name || "Ubicación actual";

setUbicacion(direccion, lat, lon);

btnUbicacion.innerHTML = '<i class="fa-solid fa-location-dot"></i> Usar mi ubicación';

}catch(err){
console.error(err);
alert("Error al obtener dirección");
btnUbicacion.innerHTML = '<i class="fa-solid fa-location-dot"></i> Usar mi ubicación';
}

}, (error) => {

alert("Debes permitir la ubicación");
btnUbicacion.innerHTML = '<i class="fa-solid fa-location-dot"></i> Usar mi ubicación';

});

});
const fechaInput = document.getElementById("fecha");

fechaInput.addEventListener("click", function() {
    this.showPicker();
});
</script>
<script>
const hamburger = document.getElementById("hamburger");
const navMenu = document.getElementById("navMenu");

hamburger.addEventListener("click", () => {
    navMenu.classList.toggle("active");
    hamburger.classList.toggle("active");
});
</script>

</body>
</html>