<?php
session_start();
require_once __DIR__ . "/config/conexion.php";

/* VALIDAR ADMIN */
if(!isset($_SESSION['Rol']) || $_SESSION['Rol'] !== 'Admin'){
    header("Location: ../index.php");
    exit();
}

/* ====== ESTADÍSTICAS ====== */
$total = $conexion->query("SELECT COUNT(*) total FROM citas")->fetch_assoc()['total'];
$pendientes = $conexion->query("SELECT COUNT(*) total FROM citas WHERE Estado='Pendiente'")->fetch_assoc()['total'];
$confirmadas = $conexion->query("SELECT COUNT(*) total FROM citas WHERE Estado='Confirmada'")->fetch_assoc()['total'];
$hoy = $conexion->query("SELECT COUNT(*) total FROM citas WHERE Fecha = CURDATE()")->fetch_assoc()['total'];

/* ====== PAGINACIÓN MENSAJES ====== */
$porPagina = 3;
$pagina = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
if($pagina < 1) $pagina = 1;

$inicio = ($pagina - 1) * $porPagina;

/* total mensajes */
$totalMensajes = $conexion->query("SELECT COUNT(*) as total FROM contactos")
    ->fetch_assoc()['total'];

$totalPaginas = ceil($totalMensajes / $porPagina);

/* mensajes paginados */
$mensajes = $conexion->query("
    SELECT 
        nombre AS Nombre,
        correo AS Correo,
        asunto AS Asunto,
        mensaje AS Mensaje,
        fecha AS Fecha
    FROM contactos
    ORDER BY fecha DESC
    LIMIT $inicio, $porPagina
");
?>

<!DOCTYPE html>
<html lang="es">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Panel Admin | Mobile Detailing RB</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="css/header.css">
<link rel="stylesheet" href="css/styles.css">
<link rel="stylesheet" href="css/admin.css">
<link rel="stylesheet" href="css/footer.css">

</head>

<body>

<?php include("includes/header.php"); ?>

<section class="admin-dashboard">

    <h1>Panel de Administración</h1>

    <!-- ===== STATS ===== -->
    <div class="stats">

        <div class="stat-card">
            <h3>Total citas</h3>
            <p><?= $total; ?></p>
        </div>

        <div class="stat-card">
            <h3>Pendientes</h3>
            <p><?= $pendientes; ?></p>
        </div>

        <div class="stat-card">
            <h3>Confirmadas</h3>
            <p><?= $confirmadas; ?></p>
        </div>

        <div class="stat-card">
            <h3>Citas hoy</h3>
            <p><?= $hoy; ?></p>
        </div>

    </div>

    <!-- ===== BOTÓN ===== -->
    <div class="panel-actions">
        <a href="citas.php" class="btn-primary">
            Administrar citas
        </a>
    </div>

    <!-- ===== MENSAJES ===== -->
    <div class="mensajes-admin">

        <h2>Mensajes de contacto</h2>

        <div class="tabla-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Correo</th>
                        <th>Asunto</th>
                        <th>Mensaje</th>
                        <th>Fecha</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if($mensajes->num_rows > 0){ ?>
                        <?php while($m = $mensajes->fetch_assoc()) { ?>
                        <tr>
                            <td><?= $m['Nombre']; ?></td>
                            <td><?= $m['Correo']; ?></td>
                            <td><?= $m['Asunto']; ?></td>

                            <!-- mensaje completo pero ordenado -->
                            <td style="white-space:normal; word-break:break-word; max-width:350px;">
                                <?= nl2br($m['Mensaje']); ?>
                            </td>

                            <td><?= $m['Fecha']; ?></td>
                        </tr>
                        <?php } ?>
                    <?php } else { ?>
                        <tr>
                            <td colspan="5">No hay mensajes aún</td>
                        </tr>
                    <?php } ?>
                </tbody>

            </table>
        </div>

        <!-- ===== PAGINACIÓN ===== -->
        <?php if($totalPaginas > 1){ ?>
        <div class="paginacion">

            <?php for($i = 1; $i <= $totalPaginas; $i++) { ?>

                <a href="?pagina=<?= $i; ?>"
                   class="<?= ($i == $pagina) ? 'active' : '' ?>">
                    <?= $i; ?>
                </a>

            <?php } ?>

        </div>
        <?php } ?>

    </div>

</section>

<script>
const hamburger = document.getElementById("hamburger");
const navMenu = document.getElementById("navMenu");

hamburger.addEventListener("click", () => {
    navMenu.classList.toggle("active");
    hamburger.classList.toggle("active");
});
</script>

<?php include("includes/footer.php"); ?>

</body>
</html>