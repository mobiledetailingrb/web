<?php
$currentPage = basename($_SERVER['PHP_SELF']);
?>

<header class="header">
    <div class="container nav-container">

        <div class="brand">
            <img src="img/logo.png" alt="Logo Mobile Detailing RB" class="logo">
            <span class="brand-name">Mobile Detailing RB</span>
        </div>

        <nav class="nav" id="navMenu">

            <a href="index.php" class="<?= ($currentPage == 'index.php') ? 'active' : '' ?>">Inicio</a>

            <a href="servicios.php" class="<?= ($currentPage == 'servicios.php') ? 'active' : '' ?>">Servicios</a>

            <a href="galeria.php" class="<?= ($currentPage == 'galeria.php') ? 'active' : '' ?>">Galería</a>

            <a href="nosotros.php" class="<?= ($currentPage == 'nosotros.php') ? 'active' : '' ?>">Nosotros</a>

            <a href="contacto.php" class="<?= ($currentPage == 'contacto.php') ? 'active' : '' ?>">Contacto</a>


            <?php if(isset($_SESSION['IdUsuario'])): ?>

                <span class="nav-user">
                    Hola, <?php echo htmlspecialchars($_SESSION['Nombre']); ?>
                </span>

                <a href="mi_cuenta.php" class="<?= ($currentPage == 'mi_cuenta.php') ? 'active' : '' ?>">Mi Cuenta</a>

                <?php if(isset($_SESSION['Rol']) && $_SESSION['Rol'] === 'Admin'): ?>
                    <a href="indexadmin.php">Panel Admin</a>
                <?php endif; ?>

                <a href="logout.php" class="btn-nav">Cerrar Sesión</a>

            <?php else: ?>

                <a href="login.php" class="btn-nav">Iniciar Sesión</a>

            <?php endif; ?>

        </nav>

        <div class="hamburger" id="hamburger">
            <span></span>
            <span></span>
            <span></span>
        </div>

    </div>
</header>