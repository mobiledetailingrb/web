<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<footer class="footer">

<div class="footer-container">

<!-- EMPRESA -->

<div class="footer-col">
<h2 class="footer-logo">Mobile Detailing RB</h2>

<p class="footer-text">
Servicio profesional de detallado automotriz en Río Bravo.
Nos especializamos en limpieza profunda, protección de pintura
y estética automotriz para que tu vehículo luzca siempre como nuevo.
</p>

</div>

<!-- ENLACES -->

<div class="footer-col">

<h3>Enlaces</h3>

<ul>

<li><a href="index.php">Inicio</a></li>
<li><a href="servicios.php">Servicios</a></li>
<li><a href="galeria.php">Galería</a></li>
<li><a href="nosotros.php">Nosotros</a></li>
<li><a href="contacto.php">Contacto</a></li>

</ul>

</div>

<!-- SERVICIOS -->

<div class="footer-col">

<h3>Servicios</h3>

<ul>

<li>Lavado premium</li>
<li>Detallado interior</li>
<li>Pulido de pintura</li>
<li>Protección cerámica</li>
<li>Servicio a domicilio</li>

</ul>

</div>

<!-- CONTACTO -->

<div class="footer-col">

<h3>Contacto</h3>

<p><i class="fa-solid fa-location-dot"></i> Río Bravo, Tamaulipas</p>
<p><i class="fa-solid fa-phone"></i> 899-156-9927</p>
<p><i class="fa-solid fa-envelope"></i> mobiledetailingrb@gmail.com</p>

<div class="footer-social">

<a href="https://www.instagram.com/mobile_detailing_rb?igsh=NTNjZ3BrN2lyMmgy"><i class="fa-brands fa-instagram"></i></a>
<a href="https://www.facebook.com/profile.php?id=61587322132386"><i class="fa-brands fa-facebook"></i></a>
<a href="https://www.tiktok.com/@mobile.detailing.rb?lang=es"><i class="fa-brands fa-tiktok"></i></a>
</div>

<a href="https://wa.me/528991569927" class="footer-whatsapp">
<i class="fa-brands fa-whatsapp"></i> Enviar WhatsApp
</a>

</div>

</div>

<div class="footer-bottom">

<div class="footer-line"></div>

<p>© 2026 Mobile Detailing RB. Todos los derechos reservados.</p>

</div>

</footer>