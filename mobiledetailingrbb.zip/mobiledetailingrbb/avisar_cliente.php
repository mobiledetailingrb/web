<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

require_once __DIR__ . "/config/conexion.php";

$idCita = $_GET['id'];

/* traer datos de la cita */
$stmt = $conexion->prepare("
    SELECT c.*, u.Correo, u.Nombre
    FROM citas c
    JOIN usuarios u ON c.IdCliente = u.IdUsuario
    WHERE c.IdCita = ?
");
$stmt->bind_param("i", $idCita);
$stmt->execute();
$cita = $stmt->get_result()->fetch_assoc();

if(!$cita){
    header("Location: citas.php");
    exit();
}

$mail = new PHPMailer(true);

try {
$mail->CharSet = 'UTF-8';
$mail->Encoding = 'base64';
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'mobiledetailingrb@gmail.com';
    $mail->Password = 'fxerwtrivxmnkybc'; // 👈 importante (no contraseña normal)
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;

    $mail->setFrom('mobiledetailingrb@gmail.com', 'Mobile Detailing RB');
    $mail->addAddress($cita['Correo'], $cita['Nombre']);

    $mail->isHTML(true);
    $mail->Subject = "🚗 Tu servicio está en camino";

    $mail->Body = "
        <h2>Hola {$cita['Nombre']}</h2>
        <p>Te informamos que tu servicio de <b>Mobile Detailing RB</b> está en camino 🚗💨</p>
        <p><b>Fecha:</b> {$cita['Fecha']}</p>
        <p><b>Hora:</b> {$cita['HoraInicio']} - {$cita['HoraFin']}</p>
        <br>
        <p>Gracias por confiar en nosotros 🙌</p>
    ";

    $mail->send();

    header("Location: citas.php?enviado=1");

} catch (Exception $e) {
    echo "Error al enviar: {$mail->ErrorInfo}";
}