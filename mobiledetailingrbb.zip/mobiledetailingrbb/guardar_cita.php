<?php

session_start();
require_once "config/conexion.php";


/* verificar sesión */

if(!isset($_SESSION['IdUsuario'])){

echo "<script>
alert('Debes iniciar sesión');
window.location='login.php';
</script>";

exit;
}


/* obtener datos del formulario */

$idCliente = $_SESSION['IdUsuario'];

$servicio = $_POST['servicio'] ?? null;
$fecha = $_POST['fecha'] ?? null;
$hora = $_POST['hora'] ?? null;

$tipoAuto = $_POST['tipo_auto'] ?? null;
$marcaAuto = $_POST['marca_auto'] ?? null;
$modeloAuto = $_POST['modelo_auto'] ?? null;

$direccion = $_POST['direccion'] ?? null;
$lat = $_POST['latitud'] ?? null;
$lng = $_POST['longitud'] ?? null;


/* obtener duración del servicio */

$sqlServicio = $conexion->query("

SELECT DuracionMinutos 
FROM servicios 
WHERE IdServicio = '$servicio'

");

$serv = $sqlServicio->fetch_assoc();

$duracion = $serv['DuracionMinutos'];


/* calcular hora inicio y fin */

$horaInicio = $hora . ":00";

$horaFin = date("H:i:s", strtotime($horaInicio) + ($duracion * 60));


/* verificar si ya existe cita en ese horario */

$check = $conexion->query("

SELECT IdCita
FROM citas
WHERE Fecha = '$fecha'
AND (
    (HoraInicio <= '$horaInicio' AND HoraFin > '$horaInicio')
    OR
    (HoraInicio < '$horaFin' AND HoraFin >= '$horaFin')
)

");

if($check->num_rows > 0){

echo "<script>
alert('Ese horario ya está ocupado');
window.history.back();
</script>";

exit;

}


/* guardar cita */

$sql = "

INSERT INTO citas
(
IdCliente,
IdServicio,
Fecha,
HoraInicio,
HoraFin,
TipoAuto,
MarcaAuto,
ModeloAuto,
DireccionTexto,
Latitud,
Longitud
)

VALUES
(
'$idCliente',
'$servicio',
'$fecha',
'$horaInicio',
'$horaFin',
'$tipoAuto',
'$marcaAuto',
'$modeloAuto',
'$direccion',
'$lat',
'$lng'
)

";


if($conexion->query($sql)){

echo "<script>
alert('Cita agendada correctamente');
window.location='mi_cuenta.php';
</script>";

}else{

echo "<script>
alert('Error al guardar la cita');
window.history.back();
</script>";

}

?>