<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
require_once "config/conexion.php";

if(!isset($_SESSION['Rol']) || $_SESSION['Rol'] !== 'Admin'){
header("Location: ../index.php");
exit();
}

$id = $_GET['id'];
$estado = $_GET['estado'];

$stmt = $conexion->prepare("
UPDATE citas 
SET Estado=? 
WHERE IdCita=?
");

$stmt->bind_param("si",$estado,$id);
$stmt->execute();

header("Location: citas.php");
exit();
