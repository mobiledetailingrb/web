<?php

require_once "config/conexion.php";

$fecha = $_GET['fecha'];

$horas = [
"09:00",
"10:00",
"11:00",
"12:00",
"13:00",
"14:00",
"15:00",
"16:00",
"17:00"
];

$sql = "SELECT HoraInicio FROM citas WHERE Fecha = '$fecha'";

$result = $conexion->query($sql);

$ocupadas = [];

while($row = $result->fetch_assoc()){

$ocupadas[] = substr($row['HoraInicio'],0,5);

}

$disponibles = array_diff($horas,$ocupadas);

echo json_encode(array_values($disponibles));