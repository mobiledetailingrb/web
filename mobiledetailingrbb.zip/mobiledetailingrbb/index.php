<?php 
session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Mobile Detailing RB</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="css/header.css">
<link rel="stylesheet" href="css/styles.css">
<link rel="stylesheet" href="css/footer.css">
</head>
<body>

<?php include("includes/header.php"); ?>

<section class="hero">
    <div class="overlay"></div>
    <div class="hero-content">
        <h1>SERVICIO DE AUTOLAVADO Y DETALLADO</h1>
<a href="agendar.php?redirect=1" class="btn-hero">AGENDAR SERVICIO</a>
    </div>
</section>

<script>
const hamburger = document.getElementById("hamburger");
const navMenu = document.getElementById("navMenu");

hamburger.addEventListener("click", () => {
    navMenu.classList.toggle("active");
    hamburger.classList.toggle("active");
});
</script>
<?php include("includes/footer.php"); ?>
</body>
</html>