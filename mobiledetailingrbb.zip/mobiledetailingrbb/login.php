<?php
session_start();
require_once __DIR__ . "/config/conexion.php";
require_once __DIR__ . "/includes/header.php";
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión | Mobile Detailing RBB</title>
    <link rel="stylesheet" href="css/header.css">
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>

<div class="contenedor-form">
    <div class="card-form">
        <h2>Iniciar Sesión</h2>
        <form action="procesar_login.php" method="POST">

            <div class="form-group">
                <label>Correo</label>
                <input type="email" name="correo" required>
            </div>

            <div class="form-group">
                <label>Contraseña</label>
                <input type="password" name="password" required>
            </div>

            <button type="submit" class="btn-principal">
                Entrar
            </button>

        </form>

        <p class="texto-secundario">
            ¿No tienes cuenta?
            <a href="registro.php">Regístrate</a>
        </p>
        <p class="texto-secundario">
    <a href="recuperar.php">¿Olvidaste tu contraseña?</a>
</p>
    </div>

</div>
<script>
const hamburger = document.getElementById("hamburger");
const navMenu = document.getElementById("navMenu");

hamburger.addEventListener("click", () => {
    navMenu.classList.toggle("active");
    hamburger.classList.toggle("active");
});
</script>
</body>
</html>