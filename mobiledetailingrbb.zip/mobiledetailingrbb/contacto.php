<?php
session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Contacto - Mobile Detailing RB</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="css/header.css">
<link rel="stylesheet" href="css/contacto.css">
<link rel="stylesheet" href="css/footer.css">

</head>
<body>

<?php include("includes/header.php"); ?>

<section class="contact-hero">

<div class="overlay"></div>

<div class="contact-wrapper">

<h2 class="contact-title">Contacto</h2>

<div class="contact-box">

<!-- INFORMACION REDES -->

<div class="contact-info">

<h3>Nuestras redes</h3>

<p>Síguenos o contáctanos directamente</p>

<div class="social-links">
<div class="social-links">

<a href="https://www.instagram.com/mobile_detailing_rb?igsh=NTNjZ3BrN2lyMmgy" target="_blank">
<i class="fa-brands fa-instagram"></i> Instagram
</a>

<a href="https://www.facebook.com/profile.php?id=61587322132386" target="_blank">
<i class="fa-brands fa-facebook"></i> Facebook
</a>

<a href="https://www.tiktok.com/@mobile.detailing.rb?lang=es" target="_blank">
<i class="fa-brands fa-facebook"></i> TikTok
</a>
<a href="https://wa.me/528991234567" class="whatsapp-btn" target="_blank">
<i class="fa-brands fa-whatsapp"></i> Enviar WhatsApp
</a>
</div>

</div>

<div class="contact-extra">

<p><strong>Email:</strong> mobiledetailingrb@gmail.com</p>
<p><strong>Ubicación:</strong> Río Bravo, Tamaulipas</p>

</div>

</div>


<!-- FORMULARIO -->

<div class="contact-form-box">

<h3>Contáctanos</h3>

<form action="guardar_contacto.php" method="POST">

<input type="text" name="nombre" placeholder="Nombre" required>

<input type="email" name="correo" placeholder="Correo electrónico" required>

<input type="text" name="asunto" placeholder="Motivo del contacto" required>

<textarea name="mensaje" placeholder="Mensaje"></textarea>

<button type="submit">Enviar mensaje</button>

</form>

</form>

</div>

</div>

</div>

</section>

<script>
const hamburger = document.getElementById("hamburger");
const navMenu = document.getElementById("navMenu");

hamburger.addEventListener("click", () => {
navMenu.classList.toggle("active");
hamburger.classList.toggle("active");
});
</script>
<?php include("includes/footer.php"); ?>
</body>
</html>