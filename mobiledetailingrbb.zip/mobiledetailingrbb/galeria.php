<?php 
session_start(); 
?>

<!DOCTYPE html>
<html lang="es">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Galería | Mobile Detailing RB</title>

<link rel="stylesheet" href="css/header.css">
<link rel="stylesheet" href="css/styles.css">
<link rel="stylesheet" href="css/galeria.css">
<link rel="stylesheet" href="css/footer.css">

</head>

<body>

<?php include("includes/header.php"); ?>


<!-- HERO -->

<section class="hero hero-galeria">

<div class="hero-content">

<h1>GALERÍA</h1>
<p>Algunos de nuestros trabajos de detallado automotriz</p>

</div>

</section>


<!-- GALERIA -->

<section class="galeria-section">

<div class="galeria-container">


<div class="galeria-item">
<img src="img/galeria/1.jpg">
</div>

<div class="galeria-item">
<img src="img/galeria/2.jpg">
</div>

<div class="galeria-item">
<img src="img/galeria/3.jpg">
</div>

<div class="galeria-item">
<img src="img/galeria/4.jpg">
</div>

<div class="galeria-item">
<img src="img/galeria/5.jpg">
</div>

<div class="galeria-item">
<img src="img/galeria/6.jpg">
</div>

<div class="galeria-item">
<img src="img/galeria/7.jpg">
</div>

<div class="galeria-item">
<img src="img/galeria/8.jpg">
</div>


</div>

</section>

<script>
const hamburger = document.getElementById("hamburger");
const navMenu = document.getElementById("navMenu");

hamburger.addEventListener("click", () => {
    navMenu.classList.toggle("active");
    hamburger.classList.toggle("active");
});
</script>
<?php include("includes/footer.php"); ?>

</body>
</html>
