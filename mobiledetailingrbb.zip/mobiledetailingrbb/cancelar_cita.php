<?php
session_start();
require_once __DIR__ . "/config/conexion.php";

if (!isset($_SESSION['IdUsuario'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: mi_cuenta.php");
    exit();
}

$idCita = $_GET['id'];
$idUsuario = $_SESSION['IdUsuario'];

/* Si tienes roles */
$esAdmin = isset($_SESSION['Rol']) && $_SESSION['Rol'] == 'admin';

if ($esAdmin) {
    $stmt = $conexion->prepare("
        UPDATE citas 
        SET Estado = 'Cancelada'
        WHERE IdCita = ?
    ");
    $stmt->bind_param("i", $idCita);
} else {
    $stmt = $conexion->prepare("
        UPDATE citas 
        SET Estado = 'Cancelada'
        WHERE IdCita = ? AND IdCliente = ?
    ");
    $stmt->bind_param("ii", $idCita, $idUsuario);
}

$stmt->execute();

/* regresar */
header("Location: cuenta.php");
exit();