<?php
session_start();
require_once __DIR__ . "/config/conexion.php";

if (!isset($_SESSION['IdUsuario'])) {
    header("Location: login.php");
    exit();
}

$idUsuario = $_SESSION['IdUsuario'];


/* ===== OBTENER DATOS DEL USUARIO ===== */

$stmt = $conexion->prepare("
    SELECT Nombre, Apellido, Correo, Telefono
    FROM usuarios
    WHERE IdUsuario = ?
");

$stmt->bind_param("i", $idUsuario);
$stmt->execute();

$usuario = $stmt->get_result()->fetch_assoc();


/* ===== ACTUALIZAR PERFIL ===== */

if (isset($_POST['guardar'])) {

    $nombre   = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $correo   = $_POST['correo'];
    $telefono = $_POST['telefono'];

    $update = $conexion->prepare("
        UPDATE usuarios
        SET Nombre = ?, Apellido = ?, Correo = ?, Telefono = ?
        WHERE IdUsuario = ?
    ");

    $update->bind_param("ssssi", $nombre, $apellido, $correo, $telefono, $idUsuario);
    $update->execute();

    header("Location:mi_cuenta.php");
    exit();
}


/* ===== CAMBIAR CONTRASEÑA ===== */

if (isset($_POST['password'])) {

    $actual = $_POST['actual'];
    $nueva  = $_POST['nueva'];

    $sql = $conexion->query("
        SELECT PasswordHash
        FROM usuarios
        WHERE IdUsuario = $idUsuario
    ");

    $row = $sql->fetch_assoc();

    if (password_verify($actual, $row['PasswordHash'])) {

        $hash = password_hash($nueva, PASSWORD_DEFAULT);

        $conexion->query("
            UPDATE usuarios
            SET PasswordHash = '$hash'
            WHERE IdUsuario = $idUsuario
        ");

        $mensaje = "Contraseña actualizada correctamente";

    } else {

        $mensaje = "Contraseña incorrecta";
    }
}
?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Perfil</title>

    <link rel="stylesheet" href="css/header.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="css/editar_perfil.css">

</head>

<body>

<?php include("includes/header.php"); ?>


<section class="cuenta-section">

    <div class="cuenta-container">

        <!-- PERFIL -->

        <div class="perfil-card">

            <h3>Editar perfil</h3>

            <form method="POST">

                <p>Nombre</p>
                <input type="text" name="nombre" value="<?php echo $usuario['Nombre']; ?>" required>

                <p>Apellido</p>
                <input type="text" name="apellido" value="<?php echo $usuario['Apellido']; ?>" required>

                <p>Email</p>
                <input type="email" name="correo" value="<?php echo $usuario['Correo']; ?>" required>

                <p>Teléfono</p>
                <input type="text" name="telefono" value="<?php echo $usuario['Telefono']; ?>" required>

                <br>

                <button type="submit" name="guardar" class="btn-editar">
                    Guardar cambios
                </button>

            </form>

        </div>


        <!-- CONTRASEÑA -->

        <div class="resumen-card">

            <h3>Cambiar contraseña</h3>

            <?php if (isset($mensaje)) { ?>
                <p><?php echo $mensaje; ?></p>
            <?php } ?>

            <form method="POST">

                <p>Contraseña actual</p>
                <input type="password" name="actual" required>

                <p>Nueva contraseña</p>
                <input type="password" name="nueva" required>

                <br>

                <button type="submit" name="password" class="btn-editar">
                    Actualizar contraseña
                </button>

            </form>

        </div>

    </div>

</section>


<?php include("includes/footer.php"); ?>

</body>
</html>