 <?php 
session_start(); 
?>

<!DOCTYPE html>
<html lang="es">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Nosotros | Mobile Detailing RB</title>

<link rel="stylesheet" href="css/header.css">
<link rel="stylesheet" href="css/styles.css">
<link rel="stylesheet" href="css/nosotros.css">
<link rel="stylesheet" href="css/footer.css">

</head>

<body>

<?php include("includes/header.php"); ?>


<!-- HERO -->
<section class="hero hero-nosotros">

    <div class="overlay"></div>

    <div class="hero-content">
        <h1>NOSOTROS</h1>
        <p>Conoce la historia de Mobile Detailing RB</p>
    </div>

</section>


<section class="nosotros-section">
    <div class="nosotros-container">
        <div class="nosotros-card">
            <h3>Nuestra historia</h3>
            <p>
            Mobile Detailing RB fue fundada el 2 de diciembre de 2025 en Río Bravo,
            Tamaulipas por Abraham Martinez y Antonio Avila. La idea nació a partir
            de una necesidad que muchas personas enfrentaban: no siempre tienen
            tiempo para llevar su vehículo a un car wash tradicional, y en muchas
            ocasiones, aun llevándolo a lavar, el resultado no era el esperado.
            </p>

            <p>
            Con nuestra experiencia y el amor que le tenemos a los autos, decidimos
            crear un servicio de detallado automotriz a domicilio. Nuestro objetivo
            es ofrecer comodidad a los clientes, visitándolos directamente en su
            casa o lugar de trabajo para realizar el servicio sin que tengan que
            mover su vehículo.
            </p>

            <p>
            Desde el inicio quisimos que cada automóvil que atendemos quede lo más
            limpio posible, cuidando cada detalle como si fuera nuestro propio
            vehículo. Creemos que un auto limpio no solo mejora su apariencia,
            sino que también refleja el cuidado que su dueño tiene por él.
            </p>

            <p>
            Conforme comenzamos a recibir más clientes, notamos que agendar citas
            por WhatsApp podía generar algunos problemas, especialmente al momento
            de compartir la ubicación en Google Maps. Por esa razón nació la idea
            de crear esta página web.
            </p>

            <p>
            Ahora los clientes pueden agendar su cita directamente desde el sitio,
            seleccionar el servicio que desean y registrar su dirección de manera
            automática. Esto nos permite organizar mejor nuestro trabajo y ofrecer
            un servicio más rápido, cómodo y eficiente.
            </p>

            <p>
            Nuestro objetivo es seguir creciendo y mejorar constantemente nuestros
            servicios para convertirnos en una empresa confiable de detallado
            automotriz a domicilio en la región, siempre trabajando con pasión
            y dedicación por los autos.
            </p>
        </div>
    </div>
</section>

<script>
const hamburger = document.getElementById("hamburger");
const navMenu = document.getElementById("navMenu");

hamburger.addEventListener("click", () => {
    navMenu.classList.toggle("active");
    hamburger.classList.toggle("active");
});
</script>
<?php include("includes/footer.php"); ?>

</body>
</html>
